let loader = document.querySelector(".preloader")

window.addEventListener("load", function(event){
    loader.style.display = "none"
})