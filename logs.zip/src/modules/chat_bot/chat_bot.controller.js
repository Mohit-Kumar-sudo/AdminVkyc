import HTTPStatus from "http-status";

const axios = require("axios");
const cheerio = require("cheerio");
const { NlpManager } = require("node-nlp");

// const manager = new NlpManager();

// Create a new instance of NlpManager
const manager = new NlpManager({ languages: ["en"] });

export async function getChatBot(req, res) {
  try {
    const { text } = req.body;

    manager.addDocument("en", text);
    console.log("Bot=============>", text);
    manager.train();

    let dataStore = [
      {
        question:
          "Dermal Fillers market [2017-2027] Middle East and Africa by Type - (USD Mn)",
        keywords: [
          "Dermal Fillers",
          "market",
          "Middle East and Africa",
          "Type"
        ],
        answer:
          "Hyaluronic acid segment accounted for the largest market share in 2019, this market is expected to reach USD 137.21 Million in 2027 from USD 105.13 Million in 2019. This market is projected to grow at a CAGR of 15.80% during the forecast period from 2020 - 2027."
      },
      {
        question:
          "Dermal Fillers market [2017-2027] Middle East and Africa by Brand",
        keywords: [
          "Dermal Fillers",
          "market",
          "Middle East and Africa",
          "Brand"
        ],
        answer:
          "Others segment accounted for the largest market share in 2019, this market is expected to reach USD 82.72 Million in 2027 from USD 54.91 Million in 2019. This market is projected to grow at a CAGR of 17.82% during the forecast period from 2020 - 2027."
      },
      {
        question: "Dermal Fillers market [2019] by North America - (USD Mn)",
        keywords: ["Dermal Fillers", "2019" ,"market", "North America"],
        answer:
          "United States accounted for the largest market share in 2019 in the North America dermal fillers market, and is expected to reach USD 1373.32 Million in 2027 from USD 917.73 Million in 2019."
      },
      {
        question: "Dermal Fillers market [2017-2027] North America by Type",
        keywords: ["Dermal Fillers", "2017-2027" ,"market", "North America", "Type"],
        answer:
          "Hyaluronic acid segment accounted for the largest market share in 2019, this market is expected to reach USD 1527.14 Million in 2027 from USD 964.59 Million in 2019. This market is projected to grow at a CAGR of 14.78% during the forecast period from 2020 - 2027."
      },
      {
        question: "Dermal Fillers market [2017-2027] North America by Brand",
        keywords: ["Dermal Fillers", "2017-2027" ,"market", "North America", "Brand"],
        answer:
          "Juvederm segment accounted for the largest market share in 2019, this market is expected to reach USD 931.48 Million in 2027 from USD 644.17 Million in 2019. This market is projected to grow at a CAGR of 13.45% during the forecast period from 2020 - 2027."
      },
      {
        question: "Military IoT market [2018-2024] South America by Component",
        keywords: ["Military IoT", "2018-2024","market", "South America", "Component"],
        answer:
          "Brazil accounted for the larger market share in 2018 in the South America military iot market, and is expected to reach USD 495.70 Million in 2024 from USD 301.80 Million in 2018.This market is projected to grow at a CAGR of 8.59% during the forecast period from 2019 - 2024."
      },
      {
        question: "Military IoT market [2018-2024] South America by Technology",
        keywords: ["Military IoT", "2018-2024" , "market", "South America", "Technology"],
        answer:
          "Others segment accounted for the largest market share in 2019, this market is expected to reach USD 82.72 Million in 2027 from USD 54.91 Million in 2019. This market is projected to grow at a CAGR of 17.82% during the forecast period from 2020 - 2027."
      },
      {
        question: "Military IoT market [2018] by North America",
        keywords: ["Military IoT", "2018" ,"market", "North America"],
        answer:
          "United States accounted for the larger market share in 2018 in the North America military iot market, and is expected to reach USD 3861.80 Million in 2024 from USD 2043.20 Million in 2018.This market is projected to grow at a CAGR of 11.19% during the forecast period from 2019 - 2024."
      },
      {
        question: "Military IoT market [2018-2024] North America by Technology",
        keywords: ["Military IoT", "market", "2018-2024" ,"North America", "Technology"],
        answer:
          "United States accounted for the larger market share in 2018 in the North America military iot market, and is expected to reach USD 3861.80 Million in 2024 from USD 2043.20 Million in 2018. This market is projected to grow at a CAGR of 11.19% during the forecast period from 2019 - 2024."
      },
      {
        question: "Prils market [2015-2023] Middle East and Africa by Type",
        keywords: ["Prils", "market", "2015-2023" ,"Middle East and Africa", "Type"],
        answer:
          "Quinapril segment accounted for the largest market share in the prils market, and is expected to reach USD 34.20 Million in 2023 from USD 29.60 Million in 2017. However, cilazapril segment is the fastest growing market, which is expected to grow at a CAGR of 3.01% during the forecast period 2018 - 2023."
      }
    ];

    let matchCount = 0;
    let answer = "";
    dataStore.forEach(data => {
      let count = 0;
      const lowerCaseKeywords = data.keywords.map(keyword =>
        keyword.toLowerCase()
      );
      for (const k of lowerCaseKeywords) {
        if (k.split(" ").length > 1) {
          lowerCaseKeywords.push(...k.split(" "));
        }
      }
      lowerCaseKeywords.forEach(keyword => {
        if (text.includes(keyword)) {
          count++;
        }
      });
      if (count > matchCount) {
        answer = data.answer;
        matchCount = count;
      }
    });
    if (answer == "") {
      answer = "Sorry I don't understand your question";
    }

    return res.status(200).json({ success: true, data: answer });
  } catch (err) {
    console.log(err);
    return res.status(HTTPStatus.BAD_REQUEST).json(err);
  }
}

async function crawlAndReply(userQuery, urls) {
  try {
    // Make a request to the website
    const extractedData = [];
    for (const url of urls) {
      const response = await axios.get(url);
      const html = response.data;

      // Use Cheerio to parse the HTML
      const $ = cheerio.load(html);

      // Extract relevant information from the website
      const websiteData = extractData($);
      manager.addDocument("en", websiteData.paragraphs);
      manager.train();

      extractedData.push(websiteData);
    }

    // Extract relevant information from the website on the basis of user query
    // const websiteData = extractedData[0];
    // const nlpResult = analyzeDataWithNLP(websiteData);

    const nlpResults = [];
    for (const websiteData of extractedData) {
      const nlpResult = analyzeDataWithNLP(userQuery, websiteData);
      nlpResults.push(nlpResult);
    }

    // Reply based on the analyzed data
    // console.log('Bot reply:', nlpResult);
    return nlpResults;
  } catch (error) {
    console.error("Error:", error.message);
  }
}

function extractData($) {
  // Replace this with your own logic to extract relevant data from the website
  const title = $("title").text();
  const paragraphs = $("p").text();

  return { title, paragraphs };
}

function analyzeDataWithNLP(userQuery, websiteData) {
  // Replace this with your actual NLP processing logic
  const response = manager.process("en", userQuery);
  return response;
}

// const websiteUrls = ['https://platform.wantstats.com', 'https://wantstats.com', 'https://www.marketresearchfuture.com/'];
const websiteUrls = [
  "https://wantstats.com",
  "https://www.marketresearchfuture.com/"
];
async function main() {
  const userQuery = "What is Wantstats";
  const nlpResults = await crawlAndReply(userQuery, websiteUrls);
  // console.log(botReply);
  if (nlpResults && nlpResults.length > 0) {
    for (const nlpResult of nlpResults) {
      // console.log(nlpResult.then((result) => {console.log(result.nluAnswer.classifications);}));
      console.log(
        nlpResult.then(result => {
          console.log(result);
        })
      );
    }
  }
}

// main();

const questions = [
  "Dermal Fillers market [2017-2027] Middle East and Africa by Type - (USD Mn)",
  "Dermal Fillers market [2017-2027] Middle East and Africa by Brand",
  "Dermal Fillers market [2019] by North America - (USD Mn)",
  "Dermal Fillers market [2017-2027] North America by Type",
  "Dermal Fillers market [2017-2027] North America by Brand",
  "Military IoT market [2018-2024] South America by Component",
  "Military IoT market [2018-2024] South America by Technology",
  "Military IoT market [2018] by North America",
  "Military IoT market [2018-2024] North America by Technology",
  "Prils market [2015-2023] Middle East and Africa by Type"
];
