export interface HttpError {
    message: string;
}