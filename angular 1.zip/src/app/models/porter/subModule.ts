export interface SubModule{
    _id: String,
    name : String,
    rating : Number,
    subModulesType : String
}
