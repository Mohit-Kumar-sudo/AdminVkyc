export interface NodeModel {
    _id : String,
    name : String,
    description : String,
    list : String
}