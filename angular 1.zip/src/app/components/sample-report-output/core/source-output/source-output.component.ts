import { Component } from '@angular/core';
@Component({
  selector: 'app-source-output',
  templateUrl: './source-output.component.html',
  styleUrls: []
})
export class SourceOutputComponent { }
