export interface OrgGridType {
    id: string,
    pid: string | null,
    name: string,
    title?: string
}