import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-executive-summary-new',
  templateUrl: './executive-summary-new.component.html',
  styleUrls: ['./executive-summary-new.component.scss']
})
export class ExecutiveSummaryNewComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
