import{a}from"./chunk-JHUYW5OK.js";import"./chunk-ISL55BQZ.js";import"./chunk-GAL4ENT6.js";export{a as Swiper,a as default};
