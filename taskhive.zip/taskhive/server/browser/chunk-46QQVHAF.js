import{a}from"./chunk-MEYUDVCN.js";import"./chunk-GAL4ENT6.js";export default a();
