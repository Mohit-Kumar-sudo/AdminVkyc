For better error handling - 
https://blog.grossman.io/how-to-write-async-await-without-try-catch-blocks-in-javascript/

npm init --yes

npm install express
npm install cross-env

npm install babel-preset-env babel-plugin-transform-object-rest-spread --save-dev

npm install webpack --save-dev
npm install babel-core babel-loader --save-dev
npm install webpack-node-externals --save-dev

npm run dev:build
npm run dev

npm install nodemon --save-dev

editorconfiggenerator, eslint plugins

npm install eslint eslint-config-equimper --save-dev

npm install mongoose body-parser compression helmet
npm install morgan --save-dev

Ctrl+Shift+P-Open User Settings->prettier.trailingComma

https://hackernoon.com/a-tale-of-webpack-4-and-how-to-finally-configure-it-in-the-right-way-4e94c8e7e5c1

npm install validator

npm install joi
npm install express-validation
npm install bcrypt-nodejs

npm install rimraf --save-dev

npm install passport passport-local
https://scotch.io/tutorials/easy-node-authentication-setup-and-local
https://codeburst.io/node-js-by-example-part-1-668376cd4f96

npm install jsonwebtoken passport-jwt
npm install slug
npm install mongoose-unique-validator
npm install http-status

npm install prettier --save-dev
npm install eslint-config-prettier --save-dev
npm run prettier
