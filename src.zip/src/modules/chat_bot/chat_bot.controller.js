import HTTPStatus from 'http-status';
import utilities from "../../utilities/utils";

export async function getChatBot(req, res) {
  try {
    const { text } = req.body;
    console.log("Bot=============>",data)
    dataStore = [
        {
          question: "What was the market size of Global IOT Market in 2022",
          keywords: ["market size", "global", "iot", "2022"],
          answer: "The market size of Global IOT Market in 2022 was $10 billion"
        },
        {
          question: "What is the growth forecast for IOT Market",
          keywords: ["growth forecast", "iot"],
          answer: "The growth forecast for IOT Market is 10%"
        },
        {
          question: "What will be the market size of US IOT Market in 2030",
          keywords: ["market size", "us", "iot", "2030"],
          answer: "The market size of US IOT Market in 2030 will be $20 billion"
        },
        {
          question: "What is the estimated revenue of Master Alloys Market in South America by Application",
          keywords: ["estimated revenue", "master alloys", "south america", "application"],
          answer: "The estimated revenue of Master Alloys Market in South America by Application is $30 billion"
        },
        {
          question: "What is the historical period for Dermal chart?",
          keywords: ["historical" , "period", "chart"],
          answer: "The historical period for this chart is 2015-2020"
        },
        {
          question: "What is the base year for this chart?",
          keywords: ["base year", "chart"],
          answer: "The base year for this chart is 2020"
        },
        {
          question: "What is the forecast period for Prils chart?",
          keywords: ["forecast period", "chart" , "Prils"],
          answer: "The forecast period for this chart is 2020-2025"
        }
      ];
      keywords = text.toLowerCase().split(" ");
      let matchCount = 0
      this.dataStore.forEach((data)=>{
        let count = 0;
        data.keywords = data.keywords.map((keyword)=> keyword.toLowerCase());
        for (const k of data.keywords) {
          if (k.split(" ").length > 1) {
            data.keywords = data.keywords.concat(k.split(" "));
          }
        }
        console.log(data.keywords);
        console.log(keywords);
        data.keywords.forEach((keyword)=>{
          if(keywords.includes(keyword)){
            count++;
          }
        })
        if(count > matchCount){
          answer = data.answer;
          matchCount = count;
        }
      })
      if(answer == ""){
        answer = "Sorry I don't understand your question";
      }

    return utilities.sendResponse(HTTPStatus.OK, answer, res);
  } catch (err) {
    return res.status(HTTPStatus.BAD_REQUEST).json(err);
  }
}

