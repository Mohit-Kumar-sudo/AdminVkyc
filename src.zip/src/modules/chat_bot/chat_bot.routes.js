import { Router } from 'express';
import * as chat_bot from './chat_bot.controller';

const routes = new Router();

routes.get('/chatData', chat_bot.getChatBot);

export default routes;
