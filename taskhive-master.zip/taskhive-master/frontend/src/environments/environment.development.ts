export const environment = {
    production: true,
    url: '//'+ window.location.hostname
  };
