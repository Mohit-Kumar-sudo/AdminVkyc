import { Component, OnInit, HostListener, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CourseService } from '../../services/course/course.service';
import { CoursesService } from '../../services/courses/courses.service';
import { environment } from '../../../environments/environment';
import { ApiService } from '../../services/api/api.service';
import * as AOS from 'aos';
import Swiper from 'swiper';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';

@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html',
  styleUrl: './course-details.component.scss'
})
export class CourseDetailsComponent implements OnInit, AfterViewInit, OnDestroy {
  myForm!: FormGroup;
  isLoading = false;
  course: any = null;
  courseId: string = '';
  otherCourses: any[] = [];
  partnersSlider: any;

  // STUDENTS / MARQUEE
  students: any[] = [];
  isStudentsLoading = false;
  studentsError: string | null = null;
  
  // Testimonial Slider properties (prefixed with 'testimonial')
  testimonials: any[] = [];
  isTestimonialsLoading = true;
  testimonialError: string | null = null;
  testimonialCurrentIndex = 0;
  testimonialCurrentTranslate = 0;
  testimonialPrevTranslate = 0;
  testimonialIsDragging = false;
  testimonialStartPosition = 0;
  testimonialCardsToShow = 3;
  testimonialCardWidth = 0;
  testimonialMaxIndex = 0;

  // Other Courses Slider properties (prefixed with 'courses')
  isOtherCoursesLoading = true;
  otherCoursesError: string | null = null;
  coursesCurrentIndex = 0;
  coursesCurrentTranslate = 0;
  coursesPrevTranslate = 0;
  coursesIsDragging = false;
  coursesStartPosition = 0;
  coursesCardsToShow = 3;
  coursesCardWidth = 0;
  coursesMaxIndex = 0;

  constructor(
    private fb: FormBuilder, 
    private _courseService: CourseService,
    private _coursesService: CoursesService,
    private _apiService: ApiService,
    private studentService: ApiService,
    private route: ActivatedRoute,
    private elRef: ElementRef
  ) {}

  ngOnInit() {
    Swiper.use([Navigation, Pagination, Autoplay]);
     this.myForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      name: ['', Validators.required],
      countryCode: ['', Validators.required],
      number: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      course: ['', Validators.required],
     });

     AOS.init({
           offset: 200, // offset (in px) from the original trigger point
           duration: 1000, // values from 0 to 3000, with step 50ms
           easing: 'ease', // default easing for AOS animations
           delay: 100, // values from 0 to 3000, with step 50ms
           once: true       // Animation occurs only once when scrolling down
         });

     // Get course ID from route
    this.route.params.subscribe(params => {
      this.courseId = params['id'];
      this.loadCourseDetails();
      this.loadOtherCourses();
      this.loadTestimonials();
      this.loadStudents();
    });
  }
  
  ngAfterViewInit(): void {
    // Initialize both sliders after DOM is fully rendered
    setTimeout(() => {
      this.initializeTestimonialSlider();
      this.initializeCoursesSlider();
      this.initPartnersSlider();
    }, 100);
  }

  ngOnDestroy() {
    if (this.partnersSlider) {
      try { this.partnersSlider.destroy(true, true); } catch (e) { /* ignore */ }
      this.partnersSlider = null;
    }
  }

  // ================= STUDENTS (MARQUEE) =================
  private loadStudents(): void {
  this.isStudentsLoading = true;
  this.studentsError = null;
  const MODEL_NAME = 'students'; // <-- matches app.use("/students", ...)
  this.studentService.get(`${MODEL_NAME}/public`, {}).subscribe({
    next: (response: any) => {
      // Accept both { data: [...] } and [...] shapes
      const payload = response && response.data ? response.data : response;
      this.students = Array.isArray(payload) ? payload : [];

      // Optional: only active students
      this.students = this.students.filter((s: any) => s.is_active !== false);

      this.isStudentsLoading = false;

      // init/re-init the swiper slider AFTER DOM updates
      setTimeout(() => {
        this.initPartnersSlider();
      }, 150);
    },
    error: (err) => {
      console.error('Error loading students:', err);
      this.studentsError = 'Failed to load student placements.';
      this.isStudentsLoading = false;
      // optionally set fallback data here
    }
  });
}

  private initPartnersSlider() {
    // If a slider already exists, destroy it first
    if (this.partnersSlider) {
      try { this.partnersSlider.destroy(true, true); } catch (e) { /* ignore */ }
      this.partnersSlider = null;
    }

    // Small guard: only init if there are slides
    if (!this.students || this.students.length === 0) {
      return;
    }

    // instantiate Swiper on .partners-slider
    this.partnersSlider = new Swiper('.partners-slider', {
      slidesPerView: 'auto',
      spaceBetween: 25,
      loop: true,
      speed: 5000,
      autoplay: {
        delay: 1,
        disableOnInteraction: false,
      },
      freeMode: {
        enabled: true,
        momentum: false,
      },
      grabCursor: false,
      allowTouchMove: false,
      breakpoints: {
        320: { spaceBetween: 15 },
        768: { spaceBetween: 25 }
      }
    });
  }

  // Helper to resolve student image -> returns absolute URL or fallback
getStudentImage(student: any): string {
  if (!student || !student.image) {
    return 'assets/images/default.png';
  }
  const img = student.image as string;

  // Already a full URL
  if (img.startsWith('http://') || img.startsWith('https://')) {
    return img;
  }

  // If image stored as 'uploads/...' or '/uploads/...'
  if (img.startsWith('uploads/') || img.startsWith('/uploads/')) {
    // ensure environment.url has no trailing slash
    return `${environment.url.replace(/\/$/, '')}/${img.replace(/^\/?/, '')}`;
  }

  // If image starts with 'assets/' -> use as-is
  if (img.startsWith('assets/')) {
    return img;
  }

  // Otherwise treat as path relative to server root
  return `${environment.url.replace(/\/$/, '')}/${img.replace(/^\/?/, '')}`;
}

trackByStudent(index: number, student: any): any {
  return student._id || student.id || index;
}

  // Window resize handler for both sliders
  @HostListener('window:resize')
  onResize() {
    this.updateTestimonialCardsToShow();
    this.updateCoursesCardsToShow();
  }

  // ============ TESTIMONIAL SLIDER METHODS ============
  initializeTestimonialSlider(): void {
    this.updateTestimonialCardsToShow();
  }

  updateTestimonialCardsToShow(): void {
    const windowWidth = window.innerWidth;
    
    if (windowWidth < 768) {
      this.testimonialCardsToShow = 1;
    } else if (windowWidth < 992) {
      this.testimonialCardsToShow = 2;
    } else {
      this.testimonialCardsToShow = 3;
    }

    const container = this.elRef.nativeElement.querySelector('.testimonials-slider');
    if (container) {
      const containerWidth = container.offsetWidth;
      this.testimonialCardWidth = containerWidth / this.testimonialCardsToShow;
      
      const cardWrappers = this.elRef.nativeElement.querySelectorAll('.testimonial-card-wrapper');
      cardWrappers.forEach((wrapper: HTMLElement) => {
        wrapper.style.width = `${100 / this.testimonialCardsToShow}%`;
      });
    }

    this.calculateTestimonialMaxIndex();
    
    if (this.testimonialCurrentIndex > this.testimonialMaxIndex) {
      this.testimonialCurrentIndex = this.testimonialMaxIndex;
    }
    
    this.setTestimonialPositionByIndex();
  }
  
  calculateTestimonialMaxIndex(): void {
    const totalCards = this.testimonials.length;
    this.testimonialMaxIndex = Math.max(0, totalCards - this.testimonialCardsToShow);
  }

  setTestimonialPositionByIndex(): void {
    const container = this.elRef.nativeElement.querySelector('.testimonials-slider');
    if (container) {
      const containerWidth = container.offsetWidth;
      this.testimonialCardWidth = containerWidth / this.testimonialCardsToShow;
    }
    
    this.testimonialCurrentTranslate = this.testimonialCurrentIndex * -this.testimonialCardWidth;
    this.testimonialPrevTranslate = this.testimonialCurrentTranslate;
    
    const sliderTrack = this.elRef.nativeElement.querySelector('.testimonials-slider-track');
    if (sliderTrack) {
      sliderTrack.style.transform = `translateX(${this.testimonialCurrentTranslate}px)`;
    }
  }

  nextTestimonialSlide(): void {
    if (this.testimonialCurrentIndex < this.testimonialMaxIndex) {
      this.testimonialCurrentIndex++;
      this.setTestimonialPositionByIndex();
    }
  }

  prevTestimonialSlide(): void {
    if (this.testimonialCurrentIndex > 0) {
      this.testimonialCurrentIndex--;
      this.setTestimonialPositionByIndex();
    }
  }
  
  goToTestimonialSlide(index: number): void {
    if (index >= 0 && index <= this.testimonialMaxIndex) {
      this.testimonialCurrentIndex = index;
      this.setTestimonialPositionByIndex();
    }
  }

  testimonialTouchStart(event: MouseEvent | TouchEvent): void {
    event.preventDefault();
    if (this.testimonialIsDragging) return;
    
    this.testimonialIsDragging = true;
    this.testimonialStartPosition = this.getPositionX(event);
    this.testimonialPrevTranslate = this.testimonialCurrentTranslate;
  }

  testimonialTouchMove(event: MouseEvent | TouchEvent): void {
    if (!this.testimonialIsDragging) return;
    
    const currentPosition = this.getPositionX(event);
    const diff = currentPosition - this.testimonialStartPosition;
    
    this.testimonialCurrentTranslate = this.testimonialPrevTranslate + diff;
    
    const minTranslate = -this.testimonialCardWidth * this.testimonialMaxIndex;
    const maxTranslate = 0;
    
    if (this.testimonialCurrentTranslate < minTranslate) {
      this.testimonialCurrentTranslate = minTranslate;
    } else if (this.testimonialCurrentTranslate > maxTranslate) {
      this.testimonialCurrentTranslate = maxTranslate;
    }
    
    const sliderTrack = this.elRef.nativeElement.querySelector('.testimonials-slider-track');
    if (sliderTrack) {
      sliderTrack.style.transform = `translateX(${this.testimonialCurrentTranslate}px)`;
    }
  }

  testimonialTouchEnd(): void {
    if (!this.testimonialIsDragging) return;
    
    this.testimonialIsDragging = false;
    
    const movedBy = this.testimonialCurrentTranslate - this.testimonialPrevTranslate;
    
    if (movedBy < -50 && this.testimonialCurrentIndex < this.testimonialMaxIndex) {
      this.testimonialCurrentIndex++;
    } else if (movedBy > 50 && this.testimonialCurrentIndex > 0) {
      this.testimonialCurrentIndex--;
    }
    
    this.setTestimonialPositionByIndex();
  }

  // ============ OTHER COURSES SLIDER METHODS ============
  initializeCoursesSlider(): void {
    this.updateCoursesCardsToShow();
  }

  updateCoursesCardsToShow(): void {
    const windowWidth = window.innerWidth;
    
    if (windowWidth < 768) {
      this.coursesCardsToShow = 1;
    } else if (windowWidth < 992) {
      this.coursesCardsToShow = 2;
    } else {
      this.coursesCardsToShow = 3;
    }

    const container = this.elRef.nativeElement.querySelector('.courses-slider');
    if (container) {
      const containerWidth = container.offsetWidth;
      this.coursesCardWidth = containerWidth / this.coursesCardsToShow;
      
      const cardWrappers = this.elRef.nativeElement.querySelectorAll('.course-card-wrapper');
      cardWrappers.forEach((wrapper: HTMLElement) => {
        wrapper.style.width = `${100 / this.coursesCardsToShow}%`;
      });
    }

    this.calculateCoursesMaxIndex();
    
    if (this.coursesCurrentIndex > this.coursesMaxIndex) {
      this.coursesCurrentIndex = this.coursesMaxIndex;
    }
    
    this.setCoursesPositionByIndex();
  }
  
  calculateCoursesMaxIndex(): void {
    const totalCards = this.otherCourses.length;
    this.coursesMaxIndex = Math.max(0, totalCards - this.coursesCardsToShow);
  }

  setCoursesPositionByIndex(): void {
    const container = this.elRef.nativeElement.querySelector('.courses-slider');
    if (container) {
      const containerWidth = container.offsetWidth;
      this.coursesCardWidth = containerWidth / this.coursesCardsToShow;
    }
    
    this.coursesCurrentTranslate = this.coursesCurrentIndex * -this.coursesCardWidth;
    this.coursesPrevTranslate = this.coursesCurrentTranslate;
    
    const sliderTrack = this.elRef.nativeElement.querySelector('.courses-slider-track');
    if (sliderTrack) {
      sliderTrack.style.transform = `translateX(${this.coursesCurrentTranslate}px)`;
    }
  }

  nextCoursesSlide(): void {
    if (this.coursesCurrentIndex < this.coursesMaxIndex) {
      this.coursesCurrentIndex++;
      this.setCoursesPositionByIndex();
    }
  }

  prevCoursesSlide(): void {
    if (this.coursesCurrentIndex > 0) {
      this.coursesCurrentIndex--;
      this.setCoursesPositionByIndex();
    }
  }
  
  goToCoursesSlide(index: number): void {
    if (index >= 0 && index <= this.coursesMaxIndex) {
      this.coursesCurrentIndex = index;
      this.setCoursesPositionByIndex();
    }
  }

  coursesTouchStart(event: MouseEvent | TouchEvent): void {
    event.preventDefault();
    if (this.coursesIsDragging) return;
    
    this.coursesIsDragging = true;
    this.coursesStartPosition = this.getPositionX(event);
    this.coursesPrevTranslate = this.coursesCurrentTranslate;
  }

  coursesTouchMove(event: MouseEvent | TouchEvent): void {
    if (!this.coursesIsDragging) return;
    
    const currentPosition = this.getPositionX(event);
    const diff = currentPosition - this.coursesStartPosition;
    
    this.coursesCurrentTranslate = this.coursesPrevTranslate + diff;
    
    const minTranslate = -this.coursesCardWidth * this.coursesMaxIndex;
    const maxTranslate = 0;
    
    if (this.coursesCurrentTranslate < minTranslate) {
      this.coursesCurrentTranslate = minTranslate;
    } else if (this.coursesCurrentTranslate > maxTranslate) {
      this.coursesCurrentTranslate = maxTranslate;
    }
    
    const sliderTrack = this.elRef.nativeElement.querySelector('.courses-slider-track');
    if (sliderTrack) {
      sliderTrack.style.transform = `translateX(${this.coursesCurrentTranslate}px)`;
    }
  }

  coursesTouchEnd(): void {
    if (!this.coursesIsDragging) return;
    
    this.coursesIsDragging = false;
    
    const movedBy = this.coursesCurrentTranslate - this.coursesPrevTranslate;
    
    if (movedBy < -50 && this.coursesCurrentIndex < this.coursesMaxIndex) {
      this.coursesCurrentIndex++;
    } else if (movedBy > 50 && this.coursesCurrentIndex > 0) {
      this.coursesCurrentIndex--;
    }
    
    this.setCoursesPositionByIndex();
  }

  // ============ SHARED UTILITY METHODS ============
  private getPositionX(event: MouseEvent | TouchEvent): number {
    return event instanceof MouseEvent 
      ? event.clientX 
      : event.touches[0].clientX;
  }

  // ============ DATA LOADING METHODS ============
  loadCourseDetails(): void {
    this._coursesService.onCoursesFindOne(this.courseId).subscribe({
      next: (response: any) => {
        this.course = response.data || response;
        
        this.myForm.patchValue({
          course: this.course.title
        });
      },
      error: (error) => {
        console.error('Error loading course details:', error);
      }
    });
  }

  loadOtherCourses(): void {
    this.isOtherCoursesLoading = true;
    this.otherCoursesError = null;
    
    this._coursesService.onCoursesGetAllPublic().subscribe({
      next: (response: any) => {
        const allCourses = response.data || response;
        this.otherCourses = allCourses.filter((course: any) => 
          course._id !== this.courseId
        );
        this.isOtherCoursesLoading = false;
        
        // Calculate max index after data is loaded
        this.calculateCoursesMaxIndex();
        
        // Initialize slider after data is loaded
        setTimeout(() => {
          this.initializeCoursesSlider();
        }, 200);
      },
      error: (error) => {
        console.error('Error loading other courses:', error);
        this.otherCoursesError = 'Failed to load courses. Please try again later.';
        this.isOtherCoursesLoading = false;
        
        // Fallback to static data if API fails
        this.loadFallbackCoursesData();
      }
    });
  }

  // Fallback data for courses in case API fails
  loadFallbackCoursesData(): void {
    this.otherCourses = [
      { 
        id: '1',
        title: 'Digital Marketing', 
        image: 'assets/images/degital-marketing-1.webp',
        description: 'Improve Your Skills With Our Course Bundles.',
        level: 'Beginner To Advanced',
        route: '/digital-marketing',
        slug: 'digital-marketing'
      },
      { 
        id: '2',
        title: 'Web Development', 
        image: 'assets/images/web-development-1.webp',
        description: 'Improve Your Skills With Our Course Bundles.',
        level: 'Beginner To Advanced',
        route: '/web-development',
        slug: 'web-development'
      },
      { 
        id: '3',
        title: 'Cyber Security', 
        image: 'assets/images/cybersecurity.webp',
        description: 'Improve Your Skills With Our Course Bundles.',
        level: 'Beginner To Advanced',
        route: '/cyber-security',
        slug: 'cyber-security'
      },
      { 
        id: '4',
        title: 'Data Science', 
        image: 'assets/images/data-science.png',
        description: 'Improve Your Skills With Our Course Bundles.',
        level: 'Beginner To Advanced',
        route: '/data-science',
        slug: 'data-science'
      },
      { 
        id: '5',
        title: 'UI/UX Design', 
        image: 'assets/images/ui-ux.png',
        description: 'Improve Your Skills With Our Course Bundles.',
        level: 'Beginner To Advanced',
        route: '/ui-ux-design',
        slug: 'ui-ux-design'
      },
      { 
        id: '6',
        title: 'Cloud Computing', 
        image: 'assets/images/cloud-computing.png',
        description: 'Improve Your Skills With Our Course Bundles.',
        level: 'Beginner To Advanced',
        route: '/cloud-computing',
        slug: 'cloud-computing'
      }
    ].filter(course => course.id !== this.courseId);
    
    this.calculateCoursesMaxIndex();
  }
  
  loadTestimonials(): void {
    this.isTestimonialsLoading = true;
    this.testimonialError = null;
    
    this._apiService.get('testimonials/public', {}).subscribe({
      next: (response: any) => {
        this.testimonials = response;
        this.isTestimonialsLoading = false;
        
        // Calculate max index after data is loaded
        this.calculateTestimonialMaxIndex();
        
        setTimeout(() => {
          this.initializeTestimonialSlider();
        }, 200);
      },
      error: (error) => {
        console.error('Error loading testimonials:', error);
        this.testimonialError = 'Failed to load testimonials. Please try again later.';
        this.isTestimonialsLoading = false;
      }
    });
  }
  
  // ============ HELPER METHODS ============
  getTestimonialImage(testimonial: any): string {
    if (!testimonial.image) {
      return 'assets/images/default.png';
    }
    if (testimonial.image.startsWith('http://') || testimonial.image.startsWith('https://')) {
      return testimonial.image;
    }
    if (testimonial.image.startsWith('assets/')) {
      return testimonial.image;
    }
    return `${environment.url}/${testimonial.image}`;
  }

  getCourseImage(course: any): string {
    let imagePath = course.image || course.thumbnail || course.imageUrl || course.photo;
    
    if (!imagePath) {
      return 'assets/images/degital-marketing-1.webp';
    }
    
    if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
      return imagePath;
    }
    
    if (imagePath.startsWith('assets/')) {
      return imagePath;
    }
    
    return `${environment.url}/${imagePath}`;
  }

  // Helper method to get course route
  getCourseRoute(course: any): string {
    return `/course/${course._id || course.id}`;
  }

  onSubmit() {
    if (this.myForm.valid) {
      this.isLoading = true;

      // Enable price field before submitting if it exists
      this.myForm.get('price')?.enable();

      this._courseService.onCourseSave(this.myForm.value).subscribe(
        (response) => {
          console.log(response);
          alert("Thank you for contacting us. We will get back to you soon.");
          this.myForm.reset();
          this.isLoading = false;

          // Re-disable price after submission if it exists
          this.myForm.get('price')?.disable();
        },
        (error) => {
          console.error(error);
          alert("Error sending contact data. Please try again.");
          this.isLoading = false;

          // Re-disable price even if there's an error
          this.myForm.get('price')?.disable();
        }
      );
    } else {
      alert("Please fill all the fields");
      this.isLoading = false;
    }
  }

  // TrackBy functions for better performance in *ngFor
  trackByTestimonial(index: number, testimonial: any): any {
    return testimonial._id || index;
  }

  trackByCourse(index: number, course: any): any {
    return course.id || course._id || index;
  }
}