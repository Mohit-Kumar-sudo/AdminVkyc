import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { PricingComponent } from './pricing/pricing.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { TermsConditionComponent } from './terms-condition/terms-condition.component';
import { ContactComponent } from './contact/contact.component';
import { BlogDetailsComponent } from './blog-details/blog-details.component';
import { ProjectDetailsComponent } from './project-details/project-details.component';
import { CoursesComponent } from './courses/courses.component';
import { CarrierComponent } from './carrier/carrier.component';
import { CarrierDetailsComponent } from './carrier-details/carrier-details.component';
import { CarrierSummaryComponent } from './carrier-summary/carrier-summary.component';
import { CarrierFormComponent } from './carrier-form/carrier-form.component';
import { CourseDetailsComponent } from './course-details/course-details.component';

const routes: Routes = [
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'about',
    component:AboutComponent
  },
  {
    path:'services',
    component:ServicesComponent
  },
  {
    path:'portfolio',
    component:PortfolioComponent
  },
  {
    path:'pricing',
    component:PricingComponent
  },
  {
    path:'privacy-policy',
    component:PrivacyPolicyComponent
  },
  {
    path:'terms-condition',
    component:TermsConditionComponent
  },
  {
    path:'contact',
    component:ContactComponent
  },
  {
    path:'course',
    component:CoursesComponent
  },
  {
    path:'career',
    component:CarrierComponent
  },
  {
    path:'career-details',
    component:CarrierDetailsComponent
  },
  {
    path:'career/:id',
    component:CarrierSummaryComponent
  },
  {
    path:'career-summary/:id',
    component:CarrierSummaryComponent
  },
  {
    path:'career-form',
    component:CarrierFormComponent
  },
  { 
    path: 'blog/:id', 
    component: BlogDetailsComponent 
  },
  { 
    path: 'project/:id', 
    component: ProjectDetailsComponent 
  },
  { 
    path: 'course/:id', 
    component: CourseDetailsComponent 
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ComponentRoutingModule { }
