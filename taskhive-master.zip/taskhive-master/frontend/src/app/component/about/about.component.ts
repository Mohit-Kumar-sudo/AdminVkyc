import { Component, OnInit, HostListener, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { environment } from '../../../environments/environment';
import * as AOS from 'aos';
import { Subscription, interval } from 'rxjs';
import { ApiService } from '../../services/api/api.service';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrl: './about.component.scss'
})
export class AboutComponent implements OnInit, OnDestroy  {
  @ViewChild('teamSliderTrack') teamSliderTrack!: ElementRef;

  teamMembers: any[] = [];
  isTeamLoading = true;
  teamError: string | null = null; 

  // Slider properties
  currentIndex = 0;
  currentTranslate = 0;
  prevTranslate = 0;
  isDragging = false;
  startPosition = 0;
  cardsToShow = 4;
  cardWidth = 0;
  maxIndex = 0;
  autoSlideInterval!: Subscription;
  autoSlideDelay = 3000; // 3 seconds


   constructor(
    private apiService: ApiService,
    private elRef: ElementRef
  ) {}

  ngOnInit() {
    AOS.init({
      offset: 200, // offset (in px) from the original trigger point
      duration: 1000, // values from 0 to 3000, with step 50ms
      easing: 'ease', // default easing for AOS animations
      delay: 100, // values from 0 to 3000, with step 50ms
      once: true       // Animation occurs only once when scrolling down
    });
    this.loadTeamMembers();
  }

  ngOnDestroy() {
    if (this.autoSlideInterval) {
      this.autoSlideInterval.unsubscribe();
    }
  }

  // Add this method to your AboutComponent class
getImageUrl(imagePath: string): string {
  if (!imagePath) {
    return '/assets/images/default.png';
  }
  
  if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
    return imagePath;
  }
  
  // Use your environment URL
  const apiBaseUrl = environment.url;
  const normalizedPath = imagePath.replace(/\\/g, '/');
  return `${apiBaseUrl}/${normalizedPath}`;
}

// Optional: Add error handling method
onImageError(event: any): void {
  event.target.src = '/assets/images/default.png';
}

  loadTeamMembers(): void {
    this.isTeamLoading = true;
    this.teamError = null;
    
    this.apiService.get('teams/public', {}).subscribe({
      next: (response: any) => {
        this.teamMembers = response.data || response;
        this.isTeamLoading = false;
        
        // Calculate max index after data is loaded
        this.calculateMaxIndex();
        
        // Initialize slider after data is loaded
        setTimeout(() => {
          this.initializeSlider();
          this.startAutoSlide();
        }, 200);
      },
      error: (error) => {
        console.error('Error loading team members:', error);
        this.teamError = 'Failed to load team members. Please try again later.';
        this.isTeamLoading = false;
        
        // Fallback to static data if API fails
        this.loadFallbackTeamData();
      }
    });
  }

  loadFallbackTeamData(): void {
    // Use the team data from your HTML as fallback
    this.teamMembers = [
      {
        name: 'Atul Chohan',
        designation: 'CEO & Founder',
        detail: 'Visionary leader with 7+ years of experience in Tech and Business Development.',
        image: '/assets/images/default.png'
      },
      {
        name: 'Mohit Kumar',
        designation: 'CTO & Founder',
        detail: 'Building Future-Ready Solutions with 7+ Years of Tech Leadership.',
        image: '/assets/images/default.png'
      },
      {
        name: 'Amit Kumar',
        designation: 'Lead Developer',
        detail: 'Full-stack developer with expertise in modern frameworks and scalable architecture.',
        image: '/assets/images/default.png'
      },
      {
        name: 'Jugal',
        designation: 'Senior Digital Marketing Manager',
        detail: 'Transforming Brands with Performance-Focused Marketing.',
        image: '/assets/images/default.png'
      },
      {
        name: 'Harsh',
        designation: 'Senior Growth Marketing Manager',
        detail: 'Focused on Growth, Powered by Strategy more than 4+ year of experience',
        image: '/assets/images/default.png'
      },
      {
        name: 'Krishna',
        designation: 'CMO',
        detail: 'More than 5+ Experience in marketing Driving Results Through Vision, Strategy, and Execution.',
        image: '/assets/images/default.png'
      },
      {
        name: 'Nainy Jain',
        designation: 'Cybersecurity Consultant',
        detail: 'Turning Cybersecurity Challenges into Trusted Solutions—5+ Years of Experience.',
        image: '/assets/images/default.png'
      }
    ];
    
    this.calculateMaxIndex();
    this.initializeSlider();
    this.startAutoSlide();
  }

  initializeSlider(): void {
    this.updateCardsToShow();
  }

  updateCardsToShow(): void {
    const windowWidth = window.innerWidth;
    
    if (windowWidth < 768) {
      this.cardsToShow = 1;
    } else if (windowWidth < 992) {
      this.cardsToShow = 2;
    } else if (windowWidth < 1200) {
      this.cardsToShow = 3;
    } else {
      this.cardsToShow = 4;
    }

    const container = this.elRef.nativeElement.querySelector('.team-slider');
    if (container) {
      const containerWidth = container.offsetWidth;
      this.cardWidth = containerWidth / this.cardsToShow;
      
      const cardWrappers = this.elRef.nativeElement.querySelectorAll('.team-card-wrapper');
      cardWrappers.forEach((wrapper: HTMLElement) => {
        wrapper.style.width = `${100 / this.cardsToShow}%`;
      });
    }

    this.calculateMaxIndex();
    
    if (this.currentIndex > this.maxIndex) {
      this.currentIndex = this.maxIndex;
    }
    
    this.setPositionByIndex();
  }
  
  calculateMaxIndex(): void {
    const totalCards = this.teamMembers.length;
    this.maxIndex = Math.max(0, totalCards - this.cardsToShow);
  }

  setPositionByIndex(): void {
    const container = this.elRef.nativeElement.querySelector('.team-slider');
    if (container) {
      const containerWidth = container.offsetWidth;
      this.cardWidth = containerWidth / this.cardsToShow;
    }
    
    this.currentTranslate = this.currentIndex * -this.cardWidth;
    this.prevTranslate = this.currentTranslate;
    
    const sliderTrack = this.elRef.nativeElement.querySelector('.team-slider-track');
    if (sliderTrack) {
      sliderTrack.style.transform = `translateX(${this.currentTranslate}px)`;
    }
  }

  nextSlide(): void {
    if (this.currentIndex < this.maxIndex) {
      this.currentIndex++;
    } else {
      // Infinite loop: go back to start
      this.currentIndex = 0;
    }
    this.setPositionByIndex();
  }

  prevSlide(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
    } else {
      // Infinite loop: go to end
      this.currentIndex = this.maxIndex;
    }
    this.setPositionByIndex();
  }
  
  goToSlide(index: number): void {
    if (index >= 0 && index <= this.maxIndex) {
      this.currentIndex = index;
      this.setPositionByIndex();
    }
  }

  startAutoSlide(): void {
    // Auto slide every 5 seconds
    this.autoSlideInterval = interval(5000).subscribe(() => {
      this.nextSlide();
    });
  }

  pauseAutoSlide(): void {
    if (this.autoSlideInterval) {
      this.autoSlideInterval.unsubscribe();
    }
  }

  resumeAutoSlide(): void {
    this.startAutoSlide();
  }

  // Touch and mouse events for dragging
  touchStart(event: MouseEvent | TouchEvent): void {
    event.preventDefault();
    if (this.isDragging) return;
    
    this.pauseAutoSlide();
    this.isDragging = true;
    this.startPosition = this.getPositionX(event);
    this.prevTranslate = this.currentTranslate;
  }

  touchMove(event: MouseEvent | TouchEvent): void {
    if (!this.isDragging) return;
    
    const currentPosition = this.getPositionX(event);
    const diff = currentPosition - this.startPosition;
    
    this.currentTranslate = this.prevTranslate + diff;
    
    const minTranslate = -this.cardWidth * this.maxIndex;
    const maxTranslate = 0;
    
    if (this.currentTranslate < minTranslate) {
      this.currentTranslate = minTranslate;
    } else if (this.currentTranslate > maxTranslate) {
      this.currentTranslate = maxTranslate;
    }
    
    const sliderTrack = this.elRef.nativeElement.querySelector('.team-slider-track');
    if (sliderTrack) {
      sliderTrack.style.transform = `translateX(${this.currentTranslate}px)`;
    }
  }

  touchEnd(): void {
    if (!this.isDragging) return;
    
    this.isDragging = false;
    this.resumeAutoSlide();
    
    const movedBy = this.currentTranslate - this.prevTranslate;
    
    if (movedBy < -50 && this.currentIndex < this.maxIndex) {
      this.currentIndex++;
    } else if (movedBy > 50 && this.currentIndex > 0) {
      this.currentIndex--;
    }
    
    this.setPositionByIndex();
  }

  private getPositionX(event: MouseEvent | TouchEvent): number {
    return event instanceof MouseEvent 
      ? event.clientX 
      : event.touches[0].clientX;
  }

  // TrackBy function for better performance in *ngFor
  trackByTeamMember(index: number, member: any): any {
    return member._id || member.name || index;
  }

  // Window resize handler
  @HostListener('window:resize')
  onResize() {
    this.updateCardsToShow();
  }
}