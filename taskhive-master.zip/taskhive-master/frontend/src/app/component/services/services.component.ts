import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import * as AOS from 'aos';
import Swiper from 'swiper';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrl: './services.component.scss'
})
export class ServicesComponent implements OnInit, AfterViewInit, OnDestroy {

    partnerLogos = [
    { name: 'Microsoft', logo: '/assets/images/Microsoft1.webp' },
    { name: 'zontal', logo: '/assets/images/zontal.webp' },
    { name: 'Makeitmud', logo: '/assets/images/makeitmud.webp' },
    { name: 'Holo', logo: '/assets/images/4.webp' },
    { name: 'Virtual Heritage', logo: '/assets/images/1.webp' },
    { name: 'Brisk Transfare', logo: '/assets/images/2.webp' },
    { name: 'Allana', logo: '/assets/images/3.webp' },
    { name: 'SakantMochan', logo: '/assets/images/sankatmochan.webp' }
  ];

    partnersSlider: any;


  ngOnInit() {
    Swiper.use([Navigation, Pagination, Autoplay]);
    AOS.init({
      offset: 200, // offset (in px) from the original trigger point
      duration: 1000, // values from 0 to 3000, with step 50ms
      easing: 'ease', // default easing for AOS animations
      delay: 100, // values from 0 to 3000, with step 50ms
      once: true       // Animation occurs only once when scrolling down
    });
  }

    ngAfterViewInit() {
    setTimeout(() => {
      this.initPartnersSlider();
    }, 100);
  }

    ngOnDestroy() {
    if (this.partnersSlider) {
      this.partnersSlider.destroy();
    }
  }

    private initPartnersSlider() {
    this.partnersSlider = new Swiper('.partners-slider', {
      slidesPerView: 'auto',
      spaceBetween: 25,
      loop: true,
      speed: 5000,
      autoplay: {
        delay: 1,
        disableOnInteraction: false,
      },
      freeMode: {
        enabled: true,
        momentum: false,
      },
      grabCursor: false,
      allowTouchMove: false,
      breakpoints: {
        320: {
          spaceBetween: 15,
        },
        768: {
          spaceBetween: 25,
        }
      }
    });
  }
}
