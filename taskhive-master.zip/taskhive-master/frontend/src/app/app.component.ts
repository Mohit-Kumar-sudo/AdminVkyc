import { Component, OnInit, Inject, PLATFORM_ID, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  template: `<router-outlet></router-outlet>`
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'taskhive';
  private isBrowser: boolean;

  constructor(
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);
    
    if (this.isBrowser) {
      this.router.events.subscribe((event) => {
        if (event instanceof NavigationEnd) {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      });
    }
  }

  async ngOnInit() {
    if (this.isBrowser) {
      await this.initializeBrowserOnlyFeatures();
    }
  }

  ngOnDestroy() {
    // Clean up any Bootstrap components if needed
  }

  private async initializeBrowserOnlyFeatures(): Promise<void> {
    try {
      // Dynamically import Bootstrap only in browser
      const bootstrap = await import('bootstrap');
      
      // Initialize Bootstrap components safely
      this.initializeBootstrapComponents(bootstrap);
      
      // Initialize AOS
      await this.initializeAOS();
      
    } catch (error) {
      console.warn('Failed to initialize browser features:', error);
    }
  }

  private initializeBootstrapComponents(bootstrap: any): void {
    // Use setTimeout to ensure DOM is fully rendered
    setTimeout(() => {
      // Initialize dropdowns
      document.querySelectorAll('[data-bs-toggle="dropdown"]').forEach(el => {
        new bootstrap.Dropdown(el);
      });

      // Initialize tooltips
      document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
        new bootstrap.Tooltip(el);
      });

      // Initialize modals
      document.querySelectorAll('[data-bs-toggle="modal"]').forEach(el => {
        new bootstrap.Modal(el);
      });

      // Initialize popovers
      document.querySelectorAll('[data-bs-toggle="popover"]').forEach(el => {
        new bootstrap.Popover(el);
      });
    }, 0);
  }

  private async initializeAOS(): Promise<void> {
    try {
      const aos = await import('aos');
      const aosLib = aos.default || aos;
      if (typeof aosLib.init === 'function') {
        aosLib.init();
      }
    } catch (error) {
      console.warn('AOS failed to load', error);
    }
  }

  public async reinitializeBootstrap(): Promise<void> {
    if (this.isBrowser) {
      try {
        const bootstrap = await import('bootstrap');
        this.initializeBootstrapComponents(bootstrap);
      } catch (error) {
        console.warn('Failed to reinitialize Bootstrap:', error);
      }
    }
  }
}