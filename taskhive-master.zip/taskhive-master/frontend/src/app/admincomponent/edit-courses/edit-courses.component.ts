import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpEventType } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api/api.service';
import { FileService } from '../../services/file/file.service';
import { environment } from '../../../environments/environment';
import { Subscription, throwError } from 'rxjs';
import { timeout, finalize, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-edit-courses',
  templateUrl: './edit-courses.component.html',
  styleUrls: ['./edit-courses.component.scss']
})
export class EditCoursesComponent implements OnInit, OnDestroy {
  env: string = environment.url;
  selectedCourse: any = {};
  myForm!: FormGroup;
  image: File[] = [];

  // upload / submit state
  uploading = false;
  uploadProgress = 0;
  uploadedImagePath: string | null = null;
  isLoading = false;

  private uploadSub?: Subscription;
  private fetchSub?: Subscription;
  private updateSub?: Subscription;

  constructor(
    private _courseService: ApiService,
    private fb: FormBuilder,
    private fileServ: FileService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.myForm = this.fb.group({
      image: [null],
      title: ['', Validators.required],
      skill: ['', Validators.required],
      duration: ['', Validators.required],
      heading: ['', [Validators.required, Validators.maxLength(600)]],
      heading0: ['', [Validators.required, Validators.maxLength(600)]],
      heading1: ['', [Validators.required, Validators.maxLength(600)]],
      description: ['', [Validators.required, Validators.maxLength(600)]],
      description0: ['', [Validators.required, Validators.maxLength(600)]],
      description1: ['', [Validators.required, Validators.maxLength(600)]],
    });
  }

  ngOnInit() {
    const courseId = this.route.snapshot.paramMap.get('id');
    if (courseId) {
      this.fetchCourseById(courseId);
    } else {
      console.error('course ID is undefined on initialization');
      this.showError('Error: course ID is undefined on initialization');
    }
  }

  ngOnDestroy() {
    this.uploadSub?.unsubscribe();
    this.fetchSub?.unsubscribe();
    this.updateSub?.unsubscribe();
  }

  private showSuccess(msg: string) {
    try {
      // If you have an AlertService globally injected elsewhere, you can swap this
      (window as any).alert ? (window as any).alert(msg) : console.log(msg);
    } catch {
      alert(msg);
    }
  }

  private showWarning(msg: string) {
    try {
      (window as any).alert ? (window as any).alert(msg) : console.warn(msg);
    } catch {
      alert(msg);
    }
  }

  private showError(msg: string) {
    try {
      (window as any).alert ? (window as any).alert(msg) : console.error(msg);
    } catch {
      alert(msg);
    }
  }

  fetchCourseById(id: string) {
    this.fetchSub = this._courseService.get(`courses/${id}`, {}).subscribe(
      (res: any) => {
        if (res && res.data && res.data._id) {
          this.selectedCourse = res.data;

          if (this.selectedCourse.image && !this.selectedCourse.image.startsWith('http')) {
            this.selectedCourse.image = this.selectedCourse.image.replace(/\\/g, '/');
          }

          this.populateForm();

          // set uploadedImagePath so if no change is made we still send the existing path
          this.uploadedImagePath = this.selectedCourse.image || null;
        } else {
          console.error('course data does not contain an _id:', res);
          this.showError('Error: course data is missing an ID.');
        }
      },
      (error) => {
        console.error(`Error fetching course with ID ${id}:`, error);
        this.showError(`Error fetching course: ${error?.message || error}`);
      }
    );
  }

  populateForm() {
    this.myForm.patchValue({
      title: this.selectedCourse.title,
      skill: this.selectedCourse.skill,
      duration: this.selectedCourse.duration,
      heading: this.selectedCourse.heading,
      heading0: this.selectedCourse.heading0,
      heading1: this.selectedCourse.heading1,
      description: this.selectedCourse.description,
      description0: this.selectedCourse.description0,
      description1: this.selectedCourse.description1,
      image: null
    });
  }

  // Called by form submit
  uploadImage() {
    // mark touched to show validators
    this.myForm.markAllAsTouched();

    if (!this.myForm.valid) {
      this.showWarning('Please fill all required fields');
      return;
    }

    // merge form values into selectedCourse
    this.selectedCourse.title = this.myForm.value.title;
    this.selectedCourse.skill = this.myForm.value.skill;
    this.selectedCourse.duration = this.myForm.value.duration;
    this.selectedCourse.heading = this.myForm.value.heading;
    this.selectedCourse.heading0 = this.myForm.value.heading0;
    this.selectedCourse.heading1 = this.myForm.value.heading1;
    this.selectedCourse.description = this.myForm.value.description;
    this.selectedCourse.description0 = this.myForm.value.description0;
    this.selectedCourse.description1 = this.myForm.value.description1;

    // if a new file has been selected but not uploaded yet -> upload first
    if (this.image.length > 0 && !this.uploadedImagePath) {
      this.uploading = true;
      this.uploadProgress = 0;

      const file = this.image[0];

      this.uploadSub = this.fileServ.uploadFile(file).pipe(
        catchError(err => {
          this.uploading = false;
          this.uploadProgress = 0;
          console.error('Error uploading image:', err);
          this.showError(`Error uploading image: ${err?.message || err}`);
          return throwError(err);
        }),
        finalize(() => {
          this.uploading = false;
        })
      ).subscribe((event: any) => {
        if (event.type === HttpEventType.UploadProgress && event.total) {
          this.uploadProgress = Math.round((event.loaded / event.total) * 100);
        } else if (event.type === HttpEventType.Response) {
          const body: any = event.body;
          if (body && body.file && body.file.path) {
            const imagePath = body.file.path.replace(/\\/g, '/');
            this.uploadedImagePath = imagePath;
            this.selectedCourse.image = imagePath;
            // proceed to update after upload finishes
            this.updateCourse();
          } else {
            console.error('Image upload response does not contain a valid path');
            this.showError('Error: Image upload failed.');
          }
        }
      });

      return;
    }

    // No new image — proceed to update
    this.updateCourse();
  }

  updateCourse() {
    // ensure correct image path is present
    if (this.uploadedImagePath) {
      this.selectedCourse.image = this.uploadedImagePath;
    }

    if (!this.selectedCourse._id) {
      console.error('Missing course id for update', this.selectedCourse);
      this.showError('Error: Missing course id.');
      return;
    }

    if (this.isLoading) return; // prevent double submits

    this.isLoading = true;

    this.updateSub = this._courseService.put('courses', this.selectedCourse._id, this.selectedCourse).pipe(
      timeout(10000),
      catchError(err => {
        return throwError(err);
      }),
      finalize(() => {
        this.isLoading = false;
      })
    ).subscribe(
      (res: any) => {
        this.showSuccess('Course updated successfully');
        alert('Course updated successfully');
        this.router.navigate(['/admin/courses']);
      },
      (error) => {
        const msg = (error?.name === 'TimeoutError') ?
          'Server timed out. Please try again later.' :
          (error?.message || 'Error updating course');
        console.error('Error updating Course:', error);
        this.showError(msg);
      }
    );
  }

  // Upload immediately on selection (preferred)
  onSelect(event: any): void {
    const file: File = event.addedFiles[0];
    if (!file) return;

    this.image = [file];
    this.uploading = true;
    this.uploadProgress = 0;
    this.uploadedImagePath = null;
    this.myForm.patchValue({ image: null });
    this.myForm.get('image')?.updateValueAndValidity();

    this.uploadSub = this.fileServ.uploadFile(file).pipe(
      catchError(err => {
        this.uploading = false;
        this.uploadProgress = 0;
        this.showError(`Image upload failed: ${err?.message || err}`);
        return throwError(err);
      }),
      finalize(() => {
        this.uploading = false;
      })
    ).subscribe((event: any) => {
      if (event.type === HttpEventType.UploadProgress && event.total) {
        this.uploadProgress = Math.round((event.loaded / event.total) * 100);
      } else if (event.type === HttpEventType.Response) {
        const body: any = event.body;
        if (body && body.file && body.file.path) {
          const imagePath = body.file.path.replace(/\\/g, '/');
          this.uploadedImagePath = imagePath;
          this.myForm.patchValue({ image: imagePath });
          this.selectedCourse.image = imagePath;
          this.myForm.get('image')?.updateValueAndValidity();
        } else {
          console.error('Upload succeeded but response missing path');
          this.showError('Upload succeeded but server did not return image path');
        }
      }
    });
  }

  onRemove(file: File): void {
    if (this.image.includes(file)) {
      this.uploadSub?.unsubscribe();
      this.uploadSub = undefined;

      this.image = [];
      this.uploading = false;
      this.uploadProgress = 0;
      this.uploadedImagePath = this.selectedCourse?.image || null;
      this.myForm.patchValue({ image: this.uploadedImagePath });
      this.myForm.get('image')?.updateValueAndValidity();
    }
  }
}