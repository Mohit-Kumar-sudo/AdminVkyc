import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpEventType } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from '../../services/alert/alert.service';
import { ApiService } from '../../services/api/api.service';
import { FileService } from '../../services/file/file.service';
import { Subscription, throwError } from 'rxjs';
import { timeout, finalize, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-add-courses',
  templateUrl: './add-courses.component.html',
  styleUrls: ['./add-courses.component.scss']
})
export class AddCoursesComponent implements OnInit, OnDestroy {
  myForm!: FormGroup;
  isLoading = false;

  // local file(s) chosen for preview
  image: File[] = [];

  // upload state
  uploading = false;
  uploadProgress = 0; // 0..100
  uploadedImagePath: string | null = null;
  private uploadSub?: Subscription;
  private postSub?: Subscription;

  constructor(
    private fb: FormBuilder,
    private fileServ: FileService,
    private _courseService: ApiService,
    private as: AlertService,
    private route: Router
  ) {
    this.myForm = this.fb.group({
      image: [null, Validators.required],
      title: ['', Validators.required],
      skill: ['', ],
      duration: ['' ],
      heading: ['' ],
      heading0: [''],
      heading1: [''],
      description: [''],
      description0: [''],
      description1: [''],
    });
  }

  ngOnInit() {}

  ngOnDestroy() {
    if (this.uploadSub) this.uploadSub.unsubscribe();
    if (this.postSub) this.postSub.unsubscribe();
  }

  // Called by the form submit button. If image already uploaded, submit fast.
  uploadImage(frm: FormGroup) {
    // mark touched to show validation errors immediately
    frm.markAllAsTouched();

    if (!frm.valid) {
      this.as?.warningToast?.('Please fill all required fields');
      return;
    }

    // If we already uploaded the image earlier, just submit
    if (this.uploadedImagePath) {
      this.myForm.patchValue({ image: this.uploadedImagePath });
      this.onSubmit(frm);
      return;
    }

    // If an image is selected but not uploaded yet, upload now
    if (this.image.length > 0 && !this.uploading) {
      this.uploading = true;
      this.uploadProgress = 0;
      const file = this.image[0];

      this.uploadSub = this.fileServ.uploadFile(file).pipe(
        // optional: you may want timeout here on upload too if desired
        catchError(err => {
          this.uploading = false;
          this.uploadProgress = 0;
          this.as?.errorToast?.(`Image upload failed: ${err?.message || err}`);
          return throwError(err);
        }),
        finalize(() => {
          this.uploading = false;
        })
      ).subscribe((event: any) => {
        if (event.type === HttpEventType.UploadProgress && event.total) {
          this.uploadProgress = Math.round((event.loaded / event.total) * 100);
        } else if (event.type === HttpEventType.Response) {
          const body: any = event.body;
          const imagePath = body?.file?.path || body?.path || null;
          if (imagePath) {
            this.uploadedImagePath = imagePath;
            this.myForm.patchValue({ image: imagePath });
            this.myForm.get('image')?.updateValueAndValidity();
            this.as?.successToast?.('Image uploaded');
            // now submit the form automatically (optional)
            this.onSubmit(frm);
          } else {
            this.as?.warningToast?.('Upload succeeded but server did not return image path.');
          }
        }
      });
    } else {
      // no image selected
      this.as?.warningToast?.('Please select an image');
    }
  }

  onSubmit(frm: FormGroup) {
    // ensure form touched / validated
    frm.markAllAsTouched();

    if (!frm.valid) {
      this.as?.warningToast?.('Please fill all required fields');
      return;
    }

    if (this.isLoading) return; // prevent double-submits

    this.isLoading = true;

    // set a timeout so the UI doesn't hang forever (10s here)
    this.postSub = this._courseService.post('courses', frm.value).pipe(
      timeout(10000),
      catchError(err => {
        // rethrow so subscriber error handler runs
        return throwError(err);
      }),
      finalize(() => {
        this.isLoading = false;
      })
    ).subscribe(
      () => {
        this.as?.successToast?.('Course added successfully');
        alert('Course added successfully');
        this.route.navigate(['/admin/courses']);
      },
      (error) => {
        const errMsg = (error?.name === 'TimeoutError') ?
          'Server is taking too long to respond. Please try again later.' :
          (error?.message || 'Error adding course');
        this.as?.errorToast?.(errMsg);
      }
    );
  }

  // Upload as soon as user selects a file (preferred)
  onSelect(event: any): void {
    const file: File = event.addedFiles[0];
    if (!file) return;

    // reset previous
    this.image = [file];
    this.uploading = true;
    this.uploadProgress = 0;
    this.uploadedImagePath = null;
    this.myForm.patchValue({ image: null });
    this.myForm.get('image')?.updateValueAndValidity();

    // start immediate upload
    this.uploadSub = this.fileServ.uploadFile(file).pipe(
      catchError(err => {
        this.uploading = false;
        this.uploadProgress = 0;
        this.as?.errorToast?.(`Image upload failed: ${err?.message || err}`);
        return throwError(err);
      }),
      finalize(() => {
        this.uploading = false;
      })
    ).subscribe((event: any) => {
      if (event.type === HttpEventType.UploadProgress && event.total) {
        this.uploadProgress = Math.round((event.loaded / event.total) * 100);
      } else if (event.type === HttpEventType.Response) {
        const body: any = event.body;
        const imagePath = body?.file?.path || body?.path || null;
        if (imagePath) {
          this.uploadedImagePath = imagePath;
          this.myForm.patchValue({ image: imagePath });
          this.myForm.get('image')?.updateValueAndValidity();
          this.as?.successToast?.('Image uploaded');
        } else {
          this.as?.warningToast?.('Upload succeeded but response missing path');
        }
      }
    });
  }

  onRemove(file: File): void {
    if (this.image.includes(file)) {
      if (this.uploadSub) {
        this.uploadSub.unsubscribe();
        this.uploadSub = undefined;
      }

      this.image = [];
      this.uploading = false;
      this.uploadProgress = 0;
      this.uploadedImagePath = null;
      this.myForm.patchValue({ image: null });
      this.myForm.get('image')?.updateValueAndValidity();
    }
  }
}