import { Component, OnInit } from '@angular/core';
import { HttpEventType } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from '../../services/alert/alert.service';
import { CoursesService } from '../../services/courses/courses.service';  
import { FileService } from '../../services/file/file.service';

@Component({
  selector: 'app-add-courses',
  templateUrl: './add-courses.component.html',
  styleUrl: './add-courses.component.scss'
})
export class AddCoursesComponent implements OnInit {
  myForm!: FormGroup;
  isLoading = false;
  image: File[] = []; 
  

  constructor(
    private fb: FormBuilder,
    private fileServ: FileService,
    private _courseService: CoursesService,
    private as: AlertService,
    private route : Router
  ) {
    this.myForm = this.fb.group({
      image: [null],
      title: ['', Validators.required],
      skill: [''],
      duration: [''],
      heading: [''],
      heading0: [''],
      heading1: [''],
      description: [''],
      description0: [''],
      description1: [''],
    });
  }

  ngOnInit() {}

  uploadImage(frm: FormGroup) {
    this.isLoading = true;
    if (this.image.length > 0) {
      this.fileServ.uploadFile(this.image[0]).subscribe(
        (res: any) => {
          if (res.type === HttpEventType.Response) {
            const body: any = res.body;
            const imagePath = body.file.path;
            this.myForm.patchValue({ image: imagePath }); // Update image path in form
            this.onSubmit(frm);
          }
        },
        (error) => {
          this.isLoading = false;
        alert(`Error uploading image: ${error.message}`);
        }
      );
    } else {
      this.isLoading = false;
    alert('Please select an image');
    }
  }

onSubmit(frm: FormGroup) {
  if (frm.valid) {
    this._courseService.post('courses', frm.value).subscribe(
      () => {
        this.isLoading = false;
        alert('Course added successfully');
        this.route.navigate(['/admin/courses']);
      },
      (error) => {
        this.isLoading = false;
        alert(`Error adding course: ${error.message}`);
      }
    );
  } else {
    this.isLoading = false;
    frm.markAllAsTouched();
    alert('Please fill all required fields');
  }
}
  
  onSelect(event: any): void {
    const file: File = event.addedFiles[0];
    if (file) {
      this.image = [file];
      this.myForm.patchValue({ image: file });
      this.myForm.get('image')?.updateValueAndValidity();
    }
  }

  onRemove(file: File): void {
    if (this.image.includes(file)) {
      this.image = [];
      this.myForm.patchValue({ image: null });
      this.myForm.get('image')?.updateValueAndValidity();
    }
  }
}