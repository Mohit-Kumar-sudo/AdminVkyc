import { Component, OnInit } from '@angular/core';
import { HttpEventType } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from '../../services/alert/alert.service';
import { CarriersService } from '../../services/carriers/carriers.service'; 

@Component({
  selector: 'app-add-carrier',
  templateUrl: './add-carrier.component.html',
  styleUrl: './add-carrier.component.scss'
})
export class AddCarrierComponent {
  myForm!: FormGroup;
  isLoading = false;
  image: File[] = [];

constructor(
    private carriersService: CarriersService,
    private fb: FormBuilder,
    private as: AlertService,
    private route : Router
  ) {
    this.myForm = this.fb.group({
      jobTitle: ['', Validators.required],
      jobRole: [''],
      jobDuration: [''],
      jobLocation: [''],
      jobSkills: [''],
      jobExperience: [''],
      jobType: [''],
      jobPreference: [''],
      jobDescription: [''],
      jobSalary: ['']
    });
  }

  ngOnInit() {}

  onSubmit(frm: FormGroup) {
  if (frm.valid) {
    this.isLoading = true;
    this.carriersService.post('carriers', frm.value).subscribe(
      (res: any) => {
        this.isLoading = false;
        if (res) {
          alert('Carrier created successfully');
          this.route.navigate(['/admin/careers']);
        } else {
          alert(`Error creating carrier: ${res.error?.message || 'Unknown error'}`);
        }
      },
      (error) => {
        this.isLoading = false;
        alert(`Error creating carrier: ${error.message}`);
      }
    );
  } else {
    this.isLoading = false;
    frm.markAllAsTouched();
    alert('Please fill all required fields');
  }
}
  
}
