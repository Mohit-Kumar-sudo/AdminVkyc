import { Component, OnInit } from '@angular/core';
import { HttpEventType } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api/api.service';
import { FileService } from '../../services/file/file.service';
import { environment } from '../../../environments/environment';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-team',
  templateUrl: './edit-team.component.html',
  styleUrl: './edit-team.component.scss'
})
export class EditTeamComponent implements OnInit {
  env: string = environment.url;
  selectedTeam: any = {};
  myForm!: FormGroup;
  image: File[] = [];

  constructor(
    private teamService: ApiService,
    private fb: FormBuilder,
    private fileServ: FileService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.myForm = this.fb.group({
      image: [null],
      name: ['' ],
      designation: [''],
      detail: [''],
    });
  }

  ngOnInit() {
    const teamId = this.route.snapshot.paramMap.get('id');
    if (teamId) {
      this.fetchTeamById(teamId);
    } else {
      console.error('Team Member ID is undefined on initialization');
      alert('Error: Team Member ID is undefined on initialization');
    }
  }

  fetchTeamById(id: string) {
    this.teamService.get(`teams/${id}`, {}).subscribe(
      (res) => {
        if (res && res.data && res.data._id) {
          this.selectedTeam = res.data;
          
          
          if (this.selectedTeam.image && !this.selectedTeam.image.startsWith('http')) {
            this.selectedTeam.image = this.selectedTeam.image.replace(/\\/g, '/');
          }
          console.log('Selected Team Member Image:', this.selectedTeam.image);


          
          this.populateForm();
        } else {
          console.error('Team Member data does not contain an _id:', res);
          alert('Error: Team Member data is missing an ID.');
        }
      },
      (error) => {
        console.error(`Error fetching Team Member with ID ${id}:`, error);
        alert(`Error fetching Team Member: ${error.message}`);
      }
    );
  }

  populateForm() {
    this.myForm.patchValue({
      name: this.selectedTeam.name,
      designation: this.selectedTeam.designation,
      detail: this.selectedTeam.detail,
      image: null
    });
  }

  handleFileInput(event: any) {
    this.selectedTeam.image = event.target.files[0];
  }

  onSelect(event: any): void {
    const file: File = event.addedFiles[0];
    if (file) {
      this.image = [file];
      this.myForm.patchValue({ image: file });
      this.myForm.get('image')?.updateValueAndValidity();
    }
  }

  onRemove(file: File): void {
    if (this.image.includes(file)) {
      this.image = [];
      this.myForm.patchValue({ image: null });
      this.myForm.get('image')?.updateValueAndValidity();
    }
  }

  uploadImage() {
    
    if (this.image.length === 0 && !this.selectedTeam.image) {
      alert('Please select an image');
      return;
    }
  
    
    this.selectedTeam.name = this.myForm.value.name;
    this.selectedTeam.designation = this.myForm.value.designation;
    this.selectedTeam.detail = this.myForm.value.detail;
  
    if (this.image.length > 0) {
      this.fileServ.uploadFile(this.image[0]).subscribe(
        (res: any) => {
          if (res.type === HttpEventType.Response) {
            const body: any = res.body;
            if (body && body.file && body.file.path) {
              const imagePath = body.file.path.replace(/\\/g, '/'); 
              this.selectedTeam.image = imagePath;
              this.updateTeam();
            } else {
              console.error('Image upload response does not contain a valid path');
              alert('Error: Image upload failed.');
            }
          }
        },
        (error) => {
          console.error('Error uploading image:', error);
          alert(`Error uploading image: ${error.message}`);
        }
      );
    } else {
      
      this.updateTeam();
    }
  }
  

  updateTeam() {
    this.teamService.put('teams', this.selectedTeam._id, this.selectedTeam).subscribe(
      () => {
        alert('Team Member updated successfully');
        this.router.navigate(['/admin/teams']);
      },
      (error) => {
        console.error('Error updating Team Member:', error);
        alert(`Error updating Team Member: ${error.message}`);
      }
    );
  }
}