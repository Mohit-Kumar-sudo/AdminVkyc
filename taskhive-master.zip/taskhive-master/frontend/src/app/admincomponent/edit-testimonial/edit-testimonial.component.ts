import { Component, OnInit } from '@angular/core';
import { HttpEventType } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api/api.service';
import { FileService } from '../../services/file/file.service';
import { environment } from '../../../environments/environment';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-edit-testimonial',
  templateUrl: './edit-testimonial.component.html',
  styleUrl: './edit-testimonial.component.scss'
})
export class EditTestimonialComponent implements OnInit {
  env: string = environment.url;
  selectedTestimonial: any = {};
  myForm!: FormGroup;
  image: File[] = [];

  constructor(
    private testimonialService: ApiService,
    private fb: FormBuilder,
    private fileServ: FileService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.myForm = this.fb.group({
      image: [null, Validators.required],
      name: ['' ],
      profession: [''],
      comment: [''],
      rating: [''],
    });
  }

  ngOnInit() {
    const testimonialId = this.route.snapshot.paramMap.get('id');
    if (testimonialId) {
      this.fetchTestimonialById(testimonialId);
    } else {
      console.error('Testimonial ID is undefined on initialization');
      alert('Error: Testimonial ID is undefined on initialization');
    }
  }

  fetchTestimonialById(id: string) {
    this.testimonialService.get(`testimonials/${id}`, {}).subscribe(
      (res) => {
        if (res && res.data && res.data._id) {
          this.selectedTestimonial = res.data;
          
          
          if (this.selectedTestimonial.image && !this.selectedTestimonial.image.startsWith('http')) {
            this.selectedTestimonial.image = this.selectedTestimonial.image.replace(/\\/g, '/');
          }
          console.log('Selected Testimonial Image:', this.selectedTestimonial.image);


          
          this.populateForm();
        } else {
          console.error('Testimonial data does not contain an _id:', res);
          alert('Error: Testimonial data is missing an ID.');
        }
      },
      (error) => {
        console.error(`Error fetching Testimonial with ID ${id}:`, error);
        alert(`Error fetching Testimonial: ${error.message}`);
      }
    );
  }

  populateForm() {
    this.myForm.patchValue({
      name: this.selectedTestimonial.name,
      profession: this.selectedTestimonial.profession,
      comment: this.selectedTestimonial.comment,
      rating: this.selectedTestimonial.rating,
      image: null
    });
  }

  handleFileInput(event: any) {
    this.selectedTestimonial.image = event.target.files[0];
  }

  onSelect(event: any): void {
    const file: File = event.addedFiles[0];
    if (file) {
      this.image = [file];
      this.myForm.patchValue({ image: file });
      this.myForm.get('image')?.updateValueAndValidity();
    }
  }

  onRemove(file: File): void {
    if (this.image.includes(file)) {
      this.image = [];
      this.myForm.patchValue({ image: null });
      this.myForm.get('image')?.updateValueAndValidity();
    }
  }

  uploadImage() {
    
    if (this.image.length === 0 && !this.selectedTestimonial.image) {
      alert('Please select an image');
      return;
    }
  
    
    this.selectedTestimonial.name = this.myForm.value.name;
    this.selectedTestimonial.profession = this.myForm.value.profession;
    this.selectedTestimonial.comment = this.myForm.value.comment;
    this.selectedTestimonial.rating = this.myForm.value.rating;
  
    if (this.image.length > 0) {
      this.fileServ.uploadFile(this.image[0]).subscribe(
        (res: any) => {
          if (res.type === HttpEventType.Response) {
            const body: any = res.body;
            if (body && body.file && body.file.path) {
              const imagePath = body.file.path.replace(/\\/g, '/'); 
              this.selectedTestimonial.image = imagePath;
              this.updateTestimonial();
            } else {
              console.error('Image upload response does not contain a valid path');
              alert('Error: Image upload failed.');
            }
          }
        },
        (error) => {
          console.error('Error uploading image:', error);
          alert(`Error uploading image: ${error.message}`);
        }
      );
    } else {
      
      this.updateTestimonial();
    }
  }
  

  updateTestimonial() {
    this.testimonialService.put('testimonials', this.selectedTestimonial._id, this.selectedTestimonial).subscribe(
      () => {
        alert('Testimonial updated successfully');
        this.router.navigate(['/admin/testimonials']);
      },
      (error) => {
        console.error('Error updating Testimonial:', error);
        alert(`Error updating Testimonial: ${error.message}`);
      }
    );
  }
}