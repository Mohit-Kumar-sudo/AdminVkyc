const mongoose = require('mongoose');

const certificatesSchema = new mongoose.Schema({
  certification_id: {
    type: String,
    unique: true
  },
  server_id: {
    type: String,
    required: true
  },
  lms_id: {
    type: String,
    required: true
  },
  'First Name': {
    type: String,
    required: true
  },
  'Last Name': {
    type: String,
    required: true
  },
  user_id: {
    type: String,
    unique: true
  },
  'Course Title': {
    type: String,
    required: true
  },
  certification_date: {
    type: Date,
    required: true
  },
  course_id: {
    type: String,
    required: true
  },
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'pending', 'expired', 'revoked', 'suspended'],
    default: 'active'
  },
  is_active: { type: Boolean, default: true, index: true },
  status: { type: String },
  created_at: { type: Date, default: Date.now },
  created_by: { type: mongoose.Types.ObjectId, default: 'self' },
  updated_at: { type: Date, default: Date.now },
  updated_by: { type: String, default: 'self' },
});

// Middleware to auto-generate certification_id and user_id before saving
certificatesSchema.pre('save', function(next) {
  const doc = this;

  // Only generate for new documents
  if (doc.isNew) {
    // 1. Generate certification_id
    // This is a simplified example. For a unique ID, you should use a library like 'uuid' or 'shortid'
    // or a more robust generation logic.
    if (!doc.certification_id) {
      // Example: 'CCKUJL96EK' -> let's make it a random string for this example
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      let result = '';
      for (let i = 0; i < 10; i++) { // Generate a 10-character string
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      doc.certification_id = result;
    }

    // 2. Generate user_id based on the provided logic
    // Logic: First initial + Last initial + first 4 chars of cert ID + next 3 chars + next 3 chars + date
    if (!doc.user_id) {
      const firstNameInitial = doc['First Name'].charAt(0).toUpperCase();
      const lastNameInitial = doc['Last Name'].charAt(0).toUpperCase();
      const certId = doc.certification_id;
      const date = new Date(doc.certification_date);
      const formattedDate = `${date.getFullYear().toString().substr(-2)}${(date.getMonth() + 1).toString().padStart(2, '0')}${date.getDate().toString().padStart(2, '0')}${date.getHours().toString().padStart(2, '0')}`;

      // Reconstruct the user_id format
      doc.user_id = `${firstNameInitial}${lastNameInitial}-${certId.substring(0, 4)}-${certId.substring(4, 7)}-${certId.substring(7)}-${formattedDate}`;
    }
  }

  // Ensure updated_at is also updated
  doc.updated_at = Date.now();

  next();
});

module.exports = mongoose.model('Certificates', certificatesSchema);